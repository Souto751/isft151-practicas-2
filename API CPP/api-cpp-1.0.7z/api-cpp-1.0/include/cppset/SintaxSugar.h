#ifndef I_SUGAR_SINTAX_H
#define I_SUGAR_SINTAX_H
#define interface struct
#define implements public
#define abstract virtual
#endif // I_SUGAR_SINTAX_H